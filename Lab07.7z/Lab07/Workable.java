public interface Workable {
    public void work();
}
