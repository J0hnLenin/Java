public interface Manageable {
    public void manage();
}
